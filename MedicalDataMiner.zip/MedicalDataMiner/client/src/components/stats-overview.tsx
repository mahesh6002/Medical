import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { FileText, Clock, CheckCircle, Database, TrendingUp } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";

interface Stats {
  totalDocuments: number;
  queueCount: number;
  successRate: number;
  dataPoints: number;
}

export default function StatsOverview() {
  const { data: stats, isLoading } = useQuery<Stats>({
    queryKey: ["/api/stats"],
  });

  if (isLoading) {
    return (
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        {[...Array(4)].map((_, i) => (
          <Card key={i}>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div className="space-y-2">
                  <Skeleton className="h-4 w-24" />
                  <Skeleton className="h-8 w-16" />
                </div>
                <Skeleton className="h-12 w-12 rounded-lg" />
              </div>
              <div className="mt-4">
                <Skeleton className="h-4 w-32" />
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    );
  }

  const statCards = [
    {
      title: "Total Documents",
      value: stats?.totalDocuments.toLocaleString() || "0",
      icon: FileText,
      iconColor: "text-blue-600",
      bgColor: "bg-blue-50 dark:bg-blue-900/20",
      trend: "+12%",
      trendText: "from last month"
    },
    {
      title: "Processing Queue",
      value: stats?.queueCount.toString() || "0",
      icon: Clock,
      iconColor: "text-yellow-600",
      bgColor: "bg-yellow-50 dark:bg-yellow-900/20",
      trend: null,
      trendText: "Average wait time: 2.3 min"
    },
    {
      title: "Success Rate",
      value: `${stats?.successRate.toFixed(1) || "0"}%`,
      icon: CheckCircle,
      iconColor: "text-green-600",
      bgColor: "bg-green-50 dark:bg-green-900/20",
      trend: "+0.3%",
      trendText: "from last week"
    },
    {
      title: "Data Points",
      value: `${(stats?.dataPoints || 0) >= 1000 ? `${Math.round((stats?.dataPoints || 0) / 1000 * 10) / 10}K` : stats?.dataPoints || "0"}`,
      icon: Database,
      iconColor: "text-purple-600",
      bgColor: "bg-purple-50 dark:bg-purple-900/20",
      trend: null,
      trendText: "Extracted this month"
    }
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
      {statCards.map((stat, index) => (
        <Card key={index} className="bg-white dark:bg-slate-800 border-slate-200 dark:border-slate-700">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-slate-600 dark:text-slate-400">{stat.title}</p>
                <p className="text-2xl font-bold text-slate-900 dark:text-slate-100">{stat.value}</p>
              </div>
              <div className={`w-12 h-12 ${stat.bgColor} rounded-lg flex items-center justify-center`}>
                <stat.icon className={`${stat.iconColor} w-6 h-6`} />
              </div>
            </div>
            <div className="mt-4 flex items-center text-sm">
              {stat.trend && (
                <>
                  <TrendingUp className="text-green-500 w-4 h-4 mr-1" />
                  <span className="text-green-600 font-medium">{stat.trend}</span>
                  <span className="text-slate-500 dark:text-slate-400 ml-1">from last month</span>
                </>
              )}
              {!stat.trend && (
                <span className="text-slate-500 dark:text-slate-400">{stat.trendText}</span>
              )}
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}
