import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { 
  Search, 
  Download, 
  Eye, 
  Trash2, 
  RotateCcw,
  FileText,
  FileImage,
  File
} from "lucide-react";
import { formatDistanceToNow } from "date-fns";

interface Document {
  id: number;
  filename: string;
  originalName: string;
  fileSize: number;
  fileType: string;
  status: string;
  patientId?: string;
  documentType?: string;
  processingProgress: number;
  uploadedAt: string;
}

interface Extraction {
  id: number;
  documentId: number;
  extractedData: any;
  dataPoints: number;
  extractedAt: string;
  confidence: number;
  reviewRequired: boolean;
  document: Document;
}

export default function DataTable() {
  const [searchQuery, setSearchQuery] = useState("");
  const [typeFilter, setTypeFilter] = useState("");
  const [selectedRows, setSelectedRows] = useState<Set<number>>(new Set());
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: extractions = [], isLoading } = useQuery<Extraction[]>({
    queryKey: ["/api/extractions"],
    refetchInterval: 5000,
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest('DELETE', `/api/documents/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/extractions"] });
      queryClient.invalidateQueries({ queryKey: ["/api/documents"] });
      queryClient.invalidateQueries({ queryKey: ["/api/stats"] });
      toast({
        title: "Document deleted",
        description: "The document has been successfully deleted.",
      });
    },
    onError: (error) => {
      toast({
        title: "Delete failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const retryMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest('POST', `/api/documents/${id}/retry`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/extractions"] });
      queryClient.invalidateQueries({ queryKey: ["/api/documents"] });
      toast({
        title: "Processing restarted",
        description: "The document has been queued for reprocessing.",
      });
    },
    onError: (error) => {
      toast({
        title: "Retry failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const exportMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest('GET', '/api/export/csv');
      const blob = await response.blob();
      
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'medical_extractions.csv';
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);
    },
    onSuccess: () => {
      toast({
        title: "Export successful",
        description: "Your data has been exported to CSV format.",
      });
    },
    onError: (error) => {
      toast({
        title: "Export failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const filteredExtractions = extractions.filter((extraction) => {
    const matchesSearch = !searchQuery || 
      extraction.document.originalName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      extraction.document.patientId?.toLowerCase().includes(searchQuery.toLowerCase()) ||
      extraction.document.documentType?.toLowerCase().includes(searchQuery.toLowerCase());
    
    const matchesType = !typeFilter || typeFilter === "all" || extraction.document.documentType === typeFilter;
    
    return matchesSearch && matchesType;
  });

  const getFileIcon = (fileType: string) => {
    if (fileType.includes('pdf')) return <FileText className="text-red-500 w-4 h-4" />;
    if (fileType.includes('image')) return <FileImage className="text-green-500 w-4 h-4" />;
    return <File className="text-slate-500 w-4 h-4" />;
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'completed':
        return <Badge className="status-badge status-completed">Completed</Badge>;
      case 'processing':
        return <Badge className="status-badge status-processing">Processing</Badge>;
      case 'error':
        return <Badge className="status-badge status-error">Error</Badge>;
      default:
        return <Badge className="status-badge status-pending">Pending</Badge>;
    }
  };

  const getDocumentTypeBadge = (type: string) => {
    const typeMap: Record<string, string> = {
      'lab_results': 'Lab Results',
      'radiology': 'Radiology',
      'clinical_notes': 'Clinical Notes',
      'prescriptions': 'Prescriptions',
      'dicom': 'DICOM'
    };

    const displayName = typeMap[type] || type;
    const className = `document-type-${type.replace('_', '-')}`;

    return <Badge className={`status-badge ${className}`}>{displayName}</Badge>;
  };

  const formatFileSize = (bytes: number) => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(1)) + ' ' + sizes[i];
  };

  const toggleRowSelection = (id: number) => {
    const newSelection = new Set(selectedRows);
    if (newSelection.has(id)) {
      newSelection.delete(id);
    } else {
      newSelection.add(id);
    }
    setSelectedRows(newSelection);
  };

  const toggleAllSelection = () => {
    if (selectedRows.size === filteredExtractions.length) {
      setSelectedRows(new Set());
    } else {
      setSelectedRows(new Set(filteredExtractions.map(e => e.document.id)));
    }
  };

  return (
    <Card className="bg-white dark:bg-slate-800 border-slate-200 dark:border-slate-700">
      <CardHeader className="border-b border-slate-200 dark:border-slate-700">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between space-y-4 sm:space-y-0">
          <div>
            <h2 className="text-lg font-semibold text-slate-900 dark:text-slate-100">Extracted Medical Data</h2>
            <p className="text-sm text-slate-500 dark:text-slate-400">Recent extractions and processing results</p>
          </div>
          <div className="flex items-center space-x-3">
            <div className="relative">
              <Search className="absolute left-3 top-2.5 h-4 w-4 text-slate-400" />
              <Input
                placeholder="Search extracted data..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10 w-64"
              />
            </div>
            <Select value={typeFilter} onValueChange={setTypeFilter}>
              <SelectTrigger className="w-40">
                <SelectValue placeholder="All Types" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Types</SelectItem>
                <SelectItem value="lab_results">Lab Results</SelectItem>
                <SelectItem value="radiology">Radiology</SelectItem>
                <SelectItem value="clinical_notes">Clinical Notes</SelectItem>
                <SelectItem value="prescriptions">Prescriptions</SelectItem>
                <SelectItem value="dicom">DICOM</SelectItem>
              </SelectContent>
            </Select>
            <Button
              onClick={() => exportMutation.mutate()}
              className="bg-primary hover:bg-primary/90"
              disabled={exportMutation.isPending}
            >
              <Download className="w-4 h-4 mr-2" />
              Export
            </Button>
          </div>
        </div>
      </CardHeader>

      <CardContent className="p-0">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-slate-50 dark:bg-slate-800 border-b border-slate-200 dark:border-slate-700">
              <tr>
                <th className="text-left py-3 px-6 text-xs font-medium text-slate-500 dark:text-slate-400 uppercase tracking-wider">
                  <Checkbox 
                    checked={selectedRows.size === filteredExtractions.length && filteredExtractions.length > 0}
                    onCheckedChange={toggleAllSelection}
                  />
                </th>
                <th className="text-left py-3 px-6 text-xs font-medium text-slate-500 dark:text-slate-400 uppercase tracking-wider">Document</th>
                <th className="text-left py-3 px-6 text-xs font-medium text-slate-500 dark:text-slate-400 uppercase tracking-wider">Type</th>
                <th className="text-left py-3 px-6 text-xs font-medium text-slate-500 dark:text-slate-400 uppercase tracking-wider">Patient ID</th>
                <th className="text-left py-3 px-6 text-xs font-medium text-slate-500 dark:text-slate-400 uppercase tracking-wider">Date</th>
                <th className="text-left py-3 px-6 text-xs font-medium text-slate-500 dark:text-slate-400 uppercase tracking-wider">Data Points</th>
                <th className="text-left py-3 px-6 text-xs font-medium text-slate-500 dark:text-slate-400 uppercase tracking-wider">Status</th>
                <th className="text-left py-3 px-6 text-xs font-medium text-slate-500 dark:text-slate-400 uppercase tracking-wider">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200 dark:divide-slate-700">
              {isLoading ? (
                [...Array(5)].map((_, i) => (
                  <tr key={i}>
                    <td colSpan={8} className="py-4 px-6">
                      <div className="animate-pulse flex space-x-4">
                        <div className="h-4 w-4 bg-slate-200 dark:bg-slate-700 rounded" />
                        <div className="flex-1 space-y-2">
                          <div className="h-4 bg-slate-200 dark:bg-slate-700 rounded w-3/4" />
                          <div className="h-4 bg-slate-200 dark:bg-slate-700 rounded w-1/2" />
                        </div>
                      </div>
                    </td>
                  </tr>
                ))
              ) : filteredExtractions.length === 0 ? (
                <tr>
                  <td colSpan={8} className="py-12 text-center">
                    <div className="text-slate-500 dark:text-slate-400">
                      <FileText className="w-12 h-12 mx-auto mb-4 opacity-50" />
                      <p className="text-lg font-medium mb-2">No extractions found</p>
                      <p className="text-sm">Upload and process some documents to see data here.</p>
                    </div>
                  </td>
                </tr>
              ) : (
                filteredExtractions.map((extraction) => (
                  <tr key={extraction.id} className="hover:bg-slate-50 dark:hover:bg-slate-700/50">
                    <td className="py-4 px-6">
                      <Checkbox 
                        checked={selectedRows.has(extraction.document.id)}
                        onCheckedChange={() => toggleRowSelection(extraction.document.id)}
                      />
                    </td>
                    <td className="py-4 px-6">
                      <div className="flex items-center space-x-3">
                        {getFileIcon(extraction.document.fileType)}
                        <div>
                          <p className="font-medium text-slate-900 dark:text-slate-100">
                            {extraction.document.originalName}
                          </p>
                          <p className="text-sm text-slate-500 dark:text-slate-400">
                            {formatFileSize(extraction.document.fileSize)}
                          </p>
                        </div>
                      </div>
                    </td>
                    <td className="py-4 px-6">
                      {extraction.document.documentType && getDocumentTypeBadge(extraction.document.documentType)}
                    </td>
                    <td className="py-4 px-6 font-mono text-sm text-slate-900 dark:text-slate-100">
                      {extraction.document.patientId || 'N/A'}
                    </td>
                    <td className="py-4 px-6 text-sm text-slate-500 dark:text-slate-400">
                      {formatDistanceToNow(new Date(extraction.extractedAt), { addSuffix: true })}
                    </td>
                    <td className="py-4 px-6 text-sm text-slate-900 dark:text-slate-100">
                      {extraction.dataPoints}
                    </td>
                    <td className="py-4 px-6">
                      {getStatusBadge(extraction.document.status)}
                    </td>
                    <td className="py-4 px-6">
                      <div className="flex items-center space-x-2">
                        <Button
                          variant="ghost"
                          size="sm"
                          className="text-primary hover:text-primary/80"
                          disabled={extraction.document.status !== 'completed'}
                        >
                          <Eye className="w-4 h-4" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          className="text-slate-400 hover:text-slate-600"
                          disabled={extraction.document.status !== 'completed'}
                        >
                          <Download className="w-4 h-4" />
                        </Button>
                        {extraction.document.status === 'error' && (
                          <Button
                            variant="ghost"
                            size="sm"
                            className="text-slate-400 hover:text-blue-600"
                            onClick={() => retryMutation.mutate(extraction.document.id)}
                            disabled={retryMutation.isPending}
                          >
                            <RotateCcw className="w-4 h-4" />
                          </Button>
                        )}
                        <Button
                          variant="ghost"
                          size="sm"
                          className="text-slate-400 hover:text-red-600"
                          onClick={() => deleteMutation.mutate(extraction.document.id)}
                          disabled={deleteMutation.isPending}
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>

        {/* Pagination */}
        {filteredExtractions.length > 0 && (
          <div className="px-6 py-4 border-t border-slate-200 dark:border-slate-700 flex items-center justify-between">
            <div className="text-sm text-slate-500 dark:text-slate-400">
              Showing <span className="font-medium">1</span> to <span className="font-medium">{Math.min(10, filteredExtractions.length)}</span> of <span className="font-medium">{filteredExtractions.length}</span> results
            </div>
            <div className="flex items-center space-x-2">
              <Button variant="outline" size="sm" disabled>
                Previous
              </Button>
              <Button size="sm" className="bg-primary text-white">1</Button>
              <Button variant="outline" size="sm" disabled>
                Next
              </Button>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
