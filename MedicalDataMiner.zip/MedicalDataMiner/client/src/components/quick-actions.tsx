import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { Upload, BarChart3, Download } from "lucide-react";

export default function QuickActions() {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const exportMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest('GET', '/api/export/csv');
      const blob = await response.blob();
      
      // Create download link
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'medical_extractions.csv';
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);
    },
    onSuccess: () => {
      toast({
        title: "Export successful",
        description: "Your data has been exported to CSV format.",
      });
    },
    onError: (error) => {
      toast({
        title: "Export failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleBulkUpload = () => {
    toast({
      title: "Bulk upload",
      description: "Use the file upload area to select multiple files at once.",
    });
  };

  const handleGenerateReport = () => {
    toast({
      title: "Report generation",
      description: "This feature will be available soon.",
    });
  };

  const handleExportData = () => {
    exportMutation.mutate();
  };

  const actions = [
    {
      icon: Upload,
      title: "Bulk Upload",
      description: "Upload multiple files",
      onClick: handleBulkUpload,
      bgColor: "bg-blue-50 dark:bg-blue-900/20",
      iconColor: "text-blue-600"
    },
    {
      icon: BarChart3,
      title: "Generate Report",
      description: "Create data summary",
      onClick: handleGenerateReport,
      bgColor: "bg-green-50 dark:bg-green-900/20",
      iconColor: "text-green-600"
    },
    {
      icon: Download,
      title: "Export Data",
      description: "CSV/Excel export",
      onClick: handleExportData,
      bgColor: "bg-purple-50 dark:bg-purple-900/20",
      iconColor: "text-purple-600",
      loading: exportMutation.isPending
    }
  ];

  return (
    <Card className="bg-white dark:bg-slate-800 border-slate-200 dark:border-slate-700">
      <CardHeader>
        <CardTitle className="text-md font-semibold text-slate-900 dark:text-slate-100">Quick Actions</CardTitle>
      </CardHeader>
      <CardContent className="p-6 pt-0">
        <div className="space-y-3">
          {actions.map((action, index) => (
            <Button
              key={index}
              variant="ghost"
              className="w-full justify-start p-3 h-auto hover:bg-slate-50 dark:hover:bg-slate-700"
              onClick={action.onClick}
              disabled={action.loading}
            >
              <div className="flex items-center space-x-3 w-full">
                <div className={`w-10 h-10 ${action.bgColor} rounded-lg flex items-center justify-center`}>
                  <action.icon className={`${action.iconColor} w-5 h-5`} />
                </div>
                <div className="text-left flex-1">
                  <p className="font-medium text-slate-900 dark:text-slate-100">{action.title}</p>
                  <p className="text-sm text-slate-500 dark:text-slate-400">{action.description}</p>
                </div>
              </div>
            </Button>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}
