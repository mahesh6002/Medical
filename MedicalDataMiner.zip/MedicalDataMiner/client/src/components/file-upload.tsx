import { useState, useRef, useCallback } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { 
  CloudUpload, 
  Plus, 
  History, 
  FileText, 
  FileImage, 
  File, 
  X,
  Loader2
} from "lucide-react";

interface Document {
  id: number;
  filename: string;
  originalName: string;
  fileSize: number;
  fileType: string;
  status: string;
  processingProgress: number;
  uploadedAt: string;
}

export default function FileUpload() {
  const [isDragOver, setIsDragOver] = useState(false);
  const [uploadingFiles, setUploadingFiles] = useState<File[]>([]);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Get processing queue
  const { data: processingQueue = [] } = useQuery<Document[]>({
    queryKey: ["/api/documents", { status: "processing" }],
    refetchInterval: 2000, // Poll every 2 seconds for updates
  });

  const uploadMutation = useMutation({
    mutationFn: async (files: File[]) => {
      const formData = new FormData();
      files.forEach(file => formData.append('files', file));
      
      const response = await apiRequest('POST', '/api/upload/bulk', formData);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/documents"] });
      queryClient.invalidateQueries({ queryKey: ["/api/stats"] });
      setUploadingFiles([]);
      toast({
        title: "Upload successful",
        description: "Files have been uploaded and processing has started.",
      });
    },
    onError: (error) => {
      toast({
        title: "Upload failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(true);
  }, []);

  const handleDragLeave = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(false);
  }, []);

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(false);
    
    const files = Array.from(e.dataTransfer.files);
    handleFiles(files);
  }, []);

  const handleFileSelect = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      const files = Array.from(e.target.files);
      handleFiles(files);
    }
  }, []);

  const handleFiles = (files: File[]) => {
    const validFiles = files.filter(file => {
      const validTypes = [
        'application/pdf',
        'application/msword',
        'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
        'text/plain',
        'image/jpeg',
        'image/png',
        'image/tiff',
        'application/dicom'
      ];
      
      const maxSize = 50 * 1024 * 1024; // 50MB
      
      if (!validTypes.includes(file.type)) {
        toast({
          title: "Invalid file type",
          description: `${file.name} is not a supported file type.`,
          variant: "destructive",
        });
        return false;
      }
      
      if (file.size > maxSize) {
        toast({
          title: "File too large",
          description: `${file.name} exceeds the 50MB limit.`,
          variant: "destructive",
        });
        return false;
      }
      
      return true;
    });

    if (validFiles.length > 0) {
      setUploadingFiles(validFiles);
      uploadMutation.mutate(validFiles);
    }
  };

  const removeUploadingFile = (index: number) => {
    setUploadingFiles(files => files.filter((_, i) => i !== index));
  };

  const getFileIcon = (fileType: string) => {
    if (fileType.includes('pdf')) return <FileText className="text-red-500 w-5 h-5" />;
    if (fileType.includes('image')) return <FileImage className="text-green-500 w-5 h-5" />;
    if (fileType.includes('word') || fileType.includes('text')) return <FileText className="text-blue-500 w-5 h-5" />;
    return <File className="text-slate-500 w-5 h-5" />;
  };

  const formatFileSize = (bytes: number) => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  return (
    <Card className="bg-white dark:bg-slate-800 border-slate-200 dark:border-slate-700">
      <CardHeader className="border-b border-slate-200 dark:border-slate-700">
        <div className="flex items-center justify-between">
          <CardTitle className="text-lg font-semibold text-slate-900 dark:text-slate-100">
            Document Upload & Processing
          </CardTitle>
          <Button variant="ghost" size="sm" className="text-primary hover:text-primary/80">
            <History className="w-4 h-4 mr-1" />
            View History
          </Button>
        </div>
      </CardHeader>

      <CardContent className="p-6">
        {/* File Upload Zone */}
        <div
          className={`file-upload-zone ${isDragOver ? 'dragover' : ''}`}
          onDragOver={handleDragOver}
          onDragLeave={handleDragLeave}
          onDrop={handleDrop}
          onClick={() => fileInputRef.current?.click()}
        >
          <div className="space-y-4">
            <div className="w-16 h-16 bg-slate-100 dark:bg-slate-700 rounded-full flex items-center justify-center mx-auto group-hover:bg-primary/10 transition-colors">
              <CloudUpload className="w-8 h-8 text-slate-400 group-hover:text-primary transition-colors" />
            </div>
            <div>
              <p className="text-lg font-medium text-slate-900 dark:text-slate-100 mb-2">
                Drop files here or click to upload
              </p>
              <p className="text-sm text-slate-500 dark:text-slate-400">
                Support for PDF, Word, Text, Images, DICOM files
              </p>
              <p className="text-xs text-slate-400 dark:text-slate-500 mt-1">
                Maximum file size: 50MB per file
              </p>
            </div>
            <Button 
              className="bg-primary hover:bg-primary/90 text-white"
              disabled={uploadMutation.isPending}
            >
              {uploadMutation.isPending ? (
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
              ) : (
                <Plus className="w-4 h-4 mr-2" />
              )}
              Select Files
            </Button>
          </div>
        </div>

        <input
          ref={fileInputRef}
          type="file"
          multiple
          className="hidden"
          accept=".pdf,.doc,.docx,.txt,.jpg,.jpeg,.png,.tiff,.dcm"
          onChange={handleFileSelect}
        />

        {/* Supported File Types */}
        <div className="mt-6">
          <p className="text-sm font-medium text-slate-700 dark:text-slate-300 mb-3">Supported File Types:</p>
          <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
            {[
              { icon: FileText, label: 'PDF', color: 'text-red-500' },
              { icon: FileText, label: 'DOC/DOCX', color: 'text-blue-500' },
              { icon: FileText, label: 'TXT', color: 'text-slate-500' },
              { icon: FileImage, label: 'JPG/PNG', color: 'text-green-500' },
              { icon: File, label: 'DICOM', color: 'text-purple-500' }
            ].map((type, index) => (
              <div key={index} className="flex items-center space-x-2 text-sm text-slate-600 dark:text-slate-400">
                <type.icon className={`${type.color} w-4 h-4`} />
                <span>{type.label}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Processing Queue */}
        {(processingQueue.length > 0 || uploadingFiles.length > 0) && (
          <div className="mt-8 border-t border-slate-200 dark:border-slate-700 pt-6">
            <h3 className="text-md font-medium text-slate-900 dark:text-slate-100 mb-4">Processing Queue</h3>
            
            <div className="space-y-3">
              {/* Show uploading files */}
              {uploadingFiles.map((file, index) => (
                <div key={`uploading-${index}`} className="flex items-center justify-between p-4 bg-slate-50 dark:bg-slate-800 rounded-lg">
                  <div className="flex items-center space-x-3">
                    {getFileIcon(file.type)}
                    <div>
                      <p className="font-medium text-slate-900 dark:text-slate-100">{file.name}</p>
                      <p className="text-sm text-slate-500 dark:text-slate-400">{formatFileSize(file.size)}</p>
                    </div>
                  </div>
                  <div className="flex items-center space-x-3">
                    <div className="flex items-center space-x-2">
                      <div className="w-32 bg-slate-200 dark:bg-slate-600 rounded-full h-2">
                        <div className="bg-primary h-2 rounded-full animate-pulse" style={{ width: '50%' }} />
                      </div>
                      <span className="text-sm font-medium text-slate-600 dark:text-slate-400">Uploading...</span>
                    </div>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => removeUploadingFile(index)}
                      className="text-slate-400 hover:text-red-500"
                    >
                      <X className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              ))}

              {/* Show processing files */}
              {processingQueue.map((doc) => (
                <div key={doc.id} className="flex items-center justify-between p-4 bg-slate-50 dark:bg-slate-800 rounded-lg">
                  <div className="flex items-center space-x-3">
                    {getFileIcon(doc.fileType)}
                    <div>
                      <p className="font-medium text-slate-900 dark:text-slate-100">{doc.originalName}</p>
                      <p className="text-sm text-slate-500 dark:text-slate-400">{formatFileSize(doc.fileSize)}</p>
                    </div>
                  </div>
                  <div className="flex items-center space-x-3">
                    <div className="flex items-center space-x-2">
                      <Progress value={doc.processingProgress} className="w-32" />
                      <span className="text-sm font-medium text-slate-600 dark:text-slate-400">
                        {doc.processingProgress}%
                      </span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
