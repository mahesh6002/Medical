export interface ProcessingStatus {
  id: string;
  filename: string;
  status: 'uploading' | 'processing' | 'completed' | 'error';
  progress: number;
  error?: string;
}

export class FileProcessingTracker {
  private static instance: FileProcessingTracker;
  private processingFiles: Map<string, ProcessingStatus> = new Map();
  private listeners: Set<(files: ProcessingStatus[]) => void> = new Set();

  static getInstance(): FileProcessingTracker {
    if (!FileProcessingTracker.instance) {
      FileProcessingTracker.instance = new FileProcessingTracker();
    }
    return FileProcessingTracker.instance;
  }

  addFile(file: File): string {
    const id = `${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
    const status: ProcessingStatus = {
      id,
      filename: file.name,
      status: 'uploading',
      progress: 0
    };
    
    this.processingFiles.set(id, status);
    this.notifyListeners();
    return id;
  }

  updateProgress(id: string, progress: number, status?: ProcessingStatus['status']) {
    const file = this.processingFiles.get(id);
    if (file) {
      file.progress = progress;
      if (status) {
        file.status = status;
      }
      this.notifyListeners();
    }
  }

  setError(id: string, error: string) {
    const file = this.processingFiles.get(id);
    if (file) {
      file.status = 'error';
      file.error = error;
      this.notifyListeners();
    }
  }

  complete(id: string) {
    const file = this.processingFiles.get(id);
    if (file) {
      file.status = 'completed';
      file.progress = 100;
      this.notifyListeners();
      
      // Remove completed files after 5 seconds
      setTimeout(() => {
        this.processingFiles.delete(id);
        this.notifyListeners();
      }, 5000);
    }
  }

  getFiles(): ProcessingStatus[] {
    return Array.from(this.processingFiles.values());
  }

  subscribe(listener: (files: ProcessingStatus[]) => void): () => void {
    this.listeners.add(listener);
    return () => {
      this.listeners.delete(listener);
    };
  }

  private notifyListeners() {
    const files = this.getFiles();
    this.listeners.forEach(listener => listener(files));
  }
}

export const fileProcessingTracker = FileProcessingTracker.getInstance();
