import { File, Bell, User } from "lucide-react";
import StatsOverview from "@/components/stats-overview";
import FileUpload from "@/components/file-upload";
import QuickActions from "@/components/quick-actions";
import RecentActivity from "@/components/recent-activity";
import DataTable from "@/components/data-table";

export default function Dashboard() {
  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-900">
      {/* Header */}
      <header className="bg-white dark:bg-slate-800 border-b border-slate-200 dark:border-slate-700 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-2">
                <File className="text-2xl text-primary" />
                <h1 className="text-xl font-bold text-slate-900 dark:text-slate-100">MedExtract Pro</h1>
              </div>
              <nav className="hidden md:flex space-x-6 ml-8">
                <a href="#dashboard" className="text-primary font-medium border-b-2 border-primary pb-4">Dashboard</a>
                <a href="#extractions" className="text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-100 pb-4">Extractions</a>
                <a href="#reports" className="text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-100 pb-4">Reports</a>
                <a href="#settings" className="text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-100 pb-4">Settings</a>
              </nav>
            </div>
            <div className="flex items-center space-x-4">
              <button className="text-slate-400 hover:text-slate-600 dark:text-slate-500 dark:hover:text-slate-300">
                <Bell className="w-5 h-5" />
              </button>
              <div className="flex items-center space-x-2">
                <div className="w-8 h-8 bg-primary text-white rounded-full flex items-center justify-center text-sm font-medium">
                  <User className="w-4 h-4" />
                </div>
                <span className="text-sm font-medium text-slate-700 dark:text-slate-300 hidden sm:block">Dr. Mahesh</span>
              </div>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Stats Overview */}
        <StatsOverview />

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mt-8">
          {/* File Upload Section */}
          <div className="lg:col-span-2">
            <FileUpload />
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            <QuickActions />
            <RecentActivity />
          </div>
        </div>

        {/* Data Table */}
        <div className="mt-8">
          <DataTable />
        </div>
      </div>
    </div>
  );
}
