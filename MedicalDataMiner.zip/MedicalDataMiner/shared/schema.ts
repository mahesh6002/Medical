import { pgTable, text, serial, integer, boolean, timestamp, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const documents = pgTable("documents", {
  id: serial("id").primaryKey(),
  filename: text("filename").notNull(),
  originalName: text("original_name").notNull(),
  fileSize: integer("file_size").notNull(),
  fileType: text("file_type").notNull(),
  uploadedAt: timestamp("uploaded_at").defaultNow().notNull(),
  status: text("status").notNull().default("pending"), // pending, processing, completed, error
  patientId: text("patient_id"),
  documentType: text("document_type"), // lab_results, radiology, clinical_notes, prescriptions, dicom
  processingProgress: integer("processing_progress").default(0),
  errorMessage: text("error_message"),
});

export const extractions = pgTable("extractions", {
  id: serial("id").primaryKey(),
  documentId: integer("document_id").notNull(),
  extractedData: jsonb("extracted_data").notNull(),
  dataPoints: integer("data_points").notNull(),
  extractedAt: timestamp("extracted_at").defaultNow().notNull(),
  confidence: integer("confidence").default(0), // 0-100
  reviewRequired: boolean("review_required").default(false),
});

export const processingJobs = pgTable("processing_jobs", {
  id: serial("id").primaryKey(),
  documentId: integer("document_id").notNull(),
  jobType: text("job_type").notNull(), // ocr, nlp, cv_metadata
  status: text("status").notNull().default("queued"), // queued, processing, completed, failed
  progress: integer("progress").default(0),
  startedAt: timestamp("started_at"),
  completedAt: timestamp("completed_at"),
  errorMessage: text("error_message"),
  result: jsonb("result"),
});

export const activityLogs = pgTable("activity_logs", {
  id: serial("id").primaryKey(),
  action: text("action").notNull(),
  description: text("description").notNull(),
  documentId: integer("document_id"),
  timestamp: timestamp("timestamp").defaultNow().notNull(),
  status: text("status").notNull(), // success, warning, error
});

export const insertDocumentSchema = createInsertSchema(documents).omit({
  id: true,
  uploadedAt: true,
});

export const insertExtractionSchema = createInsertSchema(extractions).omit({
  id: true,
  extractedAt: true,
});

export const insertProcessingJobSchema = createInsertSchema(processingJobs).omit({
  id: true,
  startedAt: true,
  completedAt: true,
});

export const insertActivityLogSchema = createInsertSchema(activityLogs).omit({
  id: true,
  timestamp: true,
});

export type Document = typeof documents.$inferSelect;
export type InsertDocument = z.infer<typeof insertDocumentSchema>;
export type Extraction = typeof extractions.$inferSelect;
export type InsertExtraction = z.infer<typeof insertExtractionSchema>;
export type ProcessingJob = typeof processingJobs.$inferSelect;
export type InsertProcessingJob = z.infer<typeof insertProcessingJobSchema>;
export type ActivityLog = typeof activityLogs.$inferSelect;
export type InsertActivityLog = z.infer<typeof insertActivityLogSchema>;
