import Tesseract from 'tesseract.js';

export interface OCRResult {
  text: string;
  confidence: number;
  words: Array<{
    text: string;
    confidence: number;
    bbox: {
      x0: number;
      y0: number;
      x1: number;
      y1: number;
    };
  }>;
}

export class OCRService {
  async processImage(imagePath: string): Promise<OCRResult> {
    try {
      const { data } = await Tesseract.recognize(imagePath, 'eng', {
        logger: (m) => {
          if (m.status === 'recognizing text') {
            console.log(`OCR Progress: ${Math.round(m.progress * 100)}%`);
          }
        }
      });

      return {
        text: data.text,
        confidence: data.confidence,
        words: data.words.map(word => ({
          text: word.text,
          confidence: word.confidence,
          bbox: word.bbox
        }))
      };
    } catch (error) {
      console.error('OCR processing failed:', error);
      throw new Error('Failed to process image with OCR');
    }
  }

  async processPDF(pdfPath: string): Promise<OCRResult[]> {
    // For PDF OCR, we would need to convert PDF pages to images first
    // This is a simplified implementation
    try {
      // In a real implementation, you would:
      // 1. Convert PDF pages to images using pdf2pic or similar
      // 2. Process each image with OCR
      // 3. Combine results
      
      const result = await this.processImage(pdfPath);
      return [result];
    } catch (error) {
      console.error('PDF OCR processing failed:', error);
      throw new Error('Failed to process PDF with OCR');
    }
  }

  extractMedicalTerms(text: string): string[] {
    // Basic medical term extraction
    const medicalTerms = [
      'blood pressure', 'heart rate', 'temperature', 'weight', 'height',
      'glucose', 'cholesterol', 'hemoglobin', 'platelet', 'white blood cell',
      'diagnosis', 'prescription', 'medication', 'dosage', 'mg', 'ml',
      'patient', 'doctor', 'physician', 'nurse', 'hospital', 'clinic'
    ];

    const foundTerms: string[] = [];
    const lowerText = text.toLowerCase();

    medicalTerms.forEach(term => {
      if (lowerText.includes(term)) {
        foundTerms.push(term);
      }
    });

    return foundTerms;
  }
}

export const ocrService = new OCRService();
