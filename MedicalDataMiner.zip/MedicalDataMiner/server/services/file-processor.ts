import path from 'path';
import { storage } from '../storage';
import { ocrService } from './ocr-service';
import { nlpService } from './nlp-service';
import type { Document, InsertProcessingJob, InsertExtraction, InsertActivityLog } from '@shared/schema';

export class FileProcessor {
  async processDocument(document: Document, filePath: string): Promise<void> {
    try {
      // Update document status to processing
      await storage.updateDocument(document.id, { 
        status: 'processing', 
        processingProgress: 0 
      });

      // Create processing job
      const job = await storage.createProcessingJob({
        documentId: document.id,
        jobType: this.getJobType(document.fileType),
        status: 'processing',
        progress: 0
      });

      // Log activity
      await storage.createActivityLog({
        action: 'processing_started',
        description: `Started processing ${document.originalName}`,
        documentId: document.id,
        status: 'success'
      });

      let extractedText = '';
      let confidence = 0;

      // Process based on file type
      if (this.isImageFile(document.fileType)) {
        const ocrResult = await ocrService.processImage(filePath);
        extractedText = ocrResult.text;
        confidence = ocrResult.confidence;
        
        // Update progress
        await storage.updateProcessingJob(job.id, { progress: 50 });
        await storage.updateDocument(document.id, { processingProgress: 50 });
        
      } else if (document.fileType === 'application/pdf') {
        const ocrResults = await ocrService.processPDF(filePath);
        extractedText = ocrResults.map(r => r.text).join('\n');
        confidence = ocrResults.reduce((sum, r) => sum + r.confidence, 0) / ocrResults.length;
        
        // Update progress
        await storage.updateProcessingJob(job.id, { progress: 50 });
        await storage.updateDocument(document.id, { processingProgress: 50 });
        
      } else if (this.isTextFile(document.fileType)) {
        // For text files, read directly
        const fs = await import('fs');
        extractedText = await fs.promises.readFile(filePath, 'utf-8');
        confidence = 100;
        
        // Update progress
        await storage.updateProcessingJob(job.id, { progress: 50 });
        await storage.updateDocument(document.id, { processingProgress: 50 });
      }

      // Extract structured data using NLP
      const structuredData = nlpService.extractStructuredData(extractedText);
      const dataPoints = nlpService.calculateDataPoints(structuredData);

      // Determine document type and patient ID from extracted data
      const documentType = this.determineDocumentType(structuredData);
      const patientId = structuredData.patientInfo.id || 'UNKNOWN';

      // Update progress
      await storage.updateProcessingJob(job.id, { progress: 80 });
      await storage.updateDocument(document.id, { processingProgress: 80 });

      // Create extraction record
      const extraction = await storage.createExtraction({
        documentId: document.id,
        extractedData: structuredData,
        dataPoints,
        confidence: Math.round(confidence),
        reviewRequired: confidence < 80 || dataPoints < 5
      });

      // Update document with final status
      await storage.updateDocument(document.id, {
        status: 'completed',
        processingProgress: 100,
        documentType,
        patientId
      });

      // Complete processing job
      await storage.updateProcessingJob(job.id, {
        status: 'completed',
        progress: 100,
        completedAt: new Date(),
        result: { extractionId: extraction.id, dataPoints }
      });

      // Log completion
      await storage.createActivityLog({
        action: 'processing_completed',
        description: `Successfully processed ${document.originalName} - extracted ${dataPoints} data points`,
        documentId: document.id,
        status: 'success'
      });

    } catch (error) {
      console.error('Document processing failed:', error);
      
      // Update document status to error
      await storage.updateDocument(document.id, {
        status: 'error',
        errorMessage: error instanceof Error ? error.message : 'Unknown error'
      });

      // Log error
      await storage.createActivityLog({
        action: 'processing_failed',
        description: `Failed to process ${document.originalName}: ${error instanceof Error ? error.message : 'Unknown error'}`,
        documentId: document.id,
        status: 'error'
      });

      throw error;
    }
  }

  private getJobType(fileType: string): string {
    if (this.isImageFile(fileType) || fileType === 'application/pdf') {
      return 'ocr';
    }
    if (this.isTextFile(fileType)) {
      return 'nlp';
    }
    if (this.isDicomFile(fileType)) {
      return 'cv_metadata';
    }
    return 'unknown';
  }

  private isImageFile(fileType: string): boolean {
    return fileType.startsWith('image/');
  }

  private isTextFile(fileType: string): boolean {
    return fileType === 'text/plain' || 
           fileType === 'application/msword' ||
           fileType === 'application/vnd.openxmlformats-officedocument.wordprocessingml.document';
  }

  private isDicomFile(fileType: string): boolean {
    return fileType === 'application/dicom' || fileType === 'application/octet-stream';
  }

  private determineDocumentType(data: any): string {
    const text = JSON.stringify(data).toLowerCase();
    
    if (text.includes('lab') || text.includes('glucose') || text.includes('cholesterol')) {
      return 'lab_results';
    }
    if (text.includes('xray') || text.includes('ct') || text.includes('mri') || text.includes('radiology')) {
      return 'radiology';
    }
    if (text.includes('prescription') || text.includes('medication') || text.includes('dosage')) {
      return 'prescriptions';
    }
    if (text.includes('clinical') || text.includes('progress') || text.includes('assessment')) {
      return 'clinical_notes';
    }
    if (text.includes('dicom')) {
      return 'dicom';
    }
    
    return 'other';
  }
}

export const fileProcessor = new FileProcessor();
