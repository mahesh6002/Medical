export interface ExtractedMedicalData {
  patientInfo: {
    name?: string;
    id?: string;
    age?: number;
    gender?: string;
    dateOfBirth?: string;
  };
  vitals: {
    bloodPressure?: string;
    heartRate?: number;
    temperature?: number;
    weight?: number;
    height?: number;
  };
  labResults: Array<{
    test: string;
    value: string;
    unit?: string;
    reference?: string;
    abnormal?: boolean;
  }>;
  medications: Array<{
    name: string;
    dosage?: string;
    frequency?: string;
    instructions?: string;
  }>;
  diagnoses: string[];
  procedures: string[];
  dates: {
    visitDate?: string;
    reportDate?: string;
  };
}

export class NLPService {
  extractStructuredData(text: string): ExtractedMedicalData {
    const data: ExtractedMedicalData = {
      patientInfo: {},
      vitals: {},
      labResults: [],
      medications: [],
      diagnoses: [],
      procedures: [],
      dates: {}
    };

    // Extract patient information
    data.patientInfo = this.extractPatientInfo(text);
    
    // Extract vital signs
    data.vitals = this.extractVitals(text);
    
    // Extract lab results
    data.labResults = this.extractLabResults(text);
    
    // Extract medications
    data.medications = this.extractMedications(text);
    
    // Extract diagnoses
    data.diagnoses = this.extractDiagnoses(text);
    
    // Extract procedures
    data.procedures = this.extractProcedures(text);
    
    // Extract dates
    data.dates = this.extractDates(text);

    return data;
  }

  private extractPatientInfo(text: string): ExtractedMedicalData['patientInfo'] {
    const info: ExtractedMedicalData['patientInfo'] = {};
    
    // Extract patient ID
    const idMatch = text.match(/(?:patient\s+(?:id|number)|pt\s+id):\s*([A-Z0-9-]+)/i);
    if (idMatch) {
      info.id = idMatch[1];
    }

    // Extract age
    const ageMatch = text.match(/age:\s*(\d+)/i);
    if (ageMatch) {
      info.age = parseInt(ageMatch[1]);
    }

    // Extract gender
    const genderMatch = text.match(/(?:gender|sex):\s*(male|female|m|f)/i);
    if (genderMatch) {
      info.gender = genderMatch[1].toLowerCase();
    }

    return info;
  }

  private extractVitals(text: string): ExtractedMedicalData['vitals'] {
    const vitals: ExtractedMedicalData['vitals'] = {};

    // Blood pressure
    const bpMatch = text.match(/(?:blood\s+pressure|bp):\s*(\d+\/\d+)/i);
    if (bpMatch) {
      vitals.bloodPressure = bpMatch[1];
    }

    // Heart rate
    const hrMatch = text.match(/(?:heart\s+rate|hr|pulse):\s*(\d+)/i);
    if (hrMatch) {
      vitals.heartRate = parseInt(hrMatch[1]);
    }

    // Temperature
    const tempMatch = text.match(/(?:temperature|temp):\s*(\d+\.?\d*)/i);
    if (tempMatch) {
      vitals.temperature = parseFloat(tempMatch[1]);
    }

    // Weight
    const weightMatch = text.match(/weight:\s*(\d+\.?\d*)/i);
    if (weightMatch) {
      vitals.weight = parseFloat(weightMatch[1]);
    }

    // Height
    const heightMatch = text.match(/height:\s*(\d+\.?\d*)/i);
    if (heightMatch) {
      vitals.height = parseFloat(heightMatch[1]);
    }

    return vitals;
  }

  private extractLabResults(text: string): ExtractedMedicalData['labResults'] {
    const results: ExtractedMedicalData['labResults'] = [];
    
    // Common lab tests patterns
    const labPatterns = [
      /(?:glucose|blood\s+sugar):\s*(\d+\.?\d*)\s*([a-z\/]+)?/i,
      /(?:cholesterol|chol):\s*(\d+\.?\d*)\s*([a-z\/]+)?/i,
      /(?:hemoglobin|hgb|hb):\s*(\d+\.?\d*)\s*([a-z\/]+)?/i,
      /(?:hematocrit|hct):\s*(\d+\.?\d*)\s*([a-z\/]+)?/i,
      /(?:white\s+blood\s+cell|wbc):\s*(\d+\.?\d*)\s*([a-z\/]+)?/i,
      /(?:platelet|plt):\s*(\d+\.?\d*)\s*([a-z\/]+)?/i
    ];

    labPatterns.forEach(pattern => {
      const matches = text.match(pattern);
      if (matches) {
        const testName = matches[0].split(':')[0].trim();
        results.push({
          test: testName,
          value: matches[1],
          unit: matches[2] || '',
          abnormal: this.isAbnormalValue(testName, parseFloat(matches[1]))
        });
      }
    });

    return results;
  }

  private extractMedications(text: string): ExtractedMedicalData['medications'] {
    const medications: ExtractedMedicalData['medications'] = [];
    
    // Look for medication patterns
    const medPatterns = [
      /(\w+)\s+(\d+\s*mg)\s+(?:(\w+\s+daily|daily|bid|tid|qid))?/gi
    ];

    medPatterns.forEach(pattern => {
      let match;
      while ((match = pattern.exec(text)) !== null) {
        medications.push({
          name: match[1],
          dosage: match[2],
          frequency: match[3] || ''
        });
      }
    });

    return medications;
  }

  private extractDiagnoses(text: string): string[] {
    const diagnoses: string[] = [];
    
    // Look for diagnosis patterns
    const diagnosisKeywords = ['diagnosis', 'impression', 'assessment'];
    
    diagnosisKeywords.forEach(keyword => {
      const regex = new RegExp(`${keyword}:\\s*([^\\n]+)`, 'i');
      const match = text.match(regex);
      if (match) {
        diagnoses.push(match[1].trim());
      }
    });

    return diagnoses;
  }

  private extractProcedures(text: string): string[] {
    const procedures: string[] = [];
    
    // Look for procedure patterns
    const procedureKeywords = ['procedure', 'operation', 'surgery', 'intervention'];
    
    procedureKeywords.forEach(keyword => {
      const regex = new RegExp(`${keyword}:\\s*([^\\n]+)`, 'i');
      const match = text.match(regex);
      if (match) {
        procedures.push(match[1].trim());
      }
    });

    return procedures;
  }

  private extractDates(text: string): ExtractedMedicalData['dates'] {
    const dates: ExtractedMedicalData['dates'] = {};
    
    // Look for various date formats
    const datePatterns = [
      /(?:date|visit\s+date):\s*(\d{1,2}\/\d{1,2}\/\d{4})/i,
      /(?:date|visit\s+date):\s*(\d{4}-\d{2}-\d{2})/i,
      /(?:report\s+date):\s*(\d{1,2}\/\d{1,2}\/\d{4})/i
    ];

    datePatterns.forEach(pattern => {
      const match = text.match(pattern);
      if (match) {
        if (pattern.source.includes('report')) {
          dates.reportDate = match[1];
        } else {
          dates.visitDate = match[1];
        }
      }
    });

    return dates;
  }

  private isAbnormalValue(testName: string, value: number): boolean {
    // Basic abnormal value detection
    const normalRanges: Record<string, { min: number; max: number }> = {
      glucose: { min: 70, max: 100 },
      cholesterol: { min: 0, max: 200 },
      hemoglobin: { min: 12, max: 16 },
      hematocrit: { min: 36, max: 46 }
    };

    const normalizedTestName = testName.toLowerCase().replace(/\s+/g, '');
    const range = normalRanges[normalizedTestName];
    
    if (range) {
      return value < range.min || value > range.max;
    }
    
    return false;
  }

  calculateDataPoints(data: ExtractedMedicalData): number {
    let points = 0;
    
    // Count patient info fields
    points += Object.values(data.patientInfo).filter(v => v !== undefined).length;
    
    // Count vitals
    points += Object.values(data.vitals).filter(v => v !== undefined).length;
    
    // Count lab results
    points += data.labResults.length;
    
    // Count medications
    points += data.medications.length;
    
    // Count diagnoses and procedures
    points += data.diagnoses.length + data.procedures.length;
    
    // Count dates
    points += Object.values(data.dates).filter(v => v !== undefined).length;
    
    return points;
  }
}

export const nlpService = new NLPService();
