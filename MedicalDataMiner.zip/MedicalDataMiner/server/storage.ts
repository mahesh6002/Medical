import { 
  documents, 
  extractions, 
  processingJobs, 
  activityLogs,
  type Document, 
  type InsertDocument,
  type Extraction,
  type InsertExtraction,
  type ProcessingJob,
  type InsertProcessingJob,
  type ActivityLog,
  type InsertActivityLog
} from "@shared/schema";

export interface IStorage {
  // Documents
  getDocument(id: number): Promise<Document | undefined>;
  getDocuments(): Promise<Document[]>;
  createDocument(document: InsertDocument): Promise<Document>;
  updateDocument(id: number, updates: Partial<Document>): Promise<Document | undefined>;
  deleteDocument(id: number): Promise<boolean>;
  getDocumentsByStatus(status: string): Promise<Document[]>;
  getDocumentsByType(documentType: string): Promise<Document[]>;
  searchDocuments(query: string): Promise<Document[]>;

  // Extractions
  getExtraction(id: number): Promise<Extraction | undefined>;
  getExtractions(): Promise<Extraction[]>;
  getExtractionsByDocument(documentId: number): Promise<Extraction[]>;
  createExtraction(extraction: InsertExtraction): Promise<Extraction>;
  updateExtraction(id: number, updates: Partial<Extraction>): Promise<Extraction | undefined>;
  deleteExtraction(id: number): Promise<boolean>;

  // Processing Jobs
  getProcessingJob(id: number): Promise<ProcessingJob | undefined>;
  getProcessingJobs(): Promise<ProcessingJob[]>;
  getProcessingJobsByDocument(documentId: number): Promise<ProcessingJob[]>;
  getProcessingJobsByStatus(status: string): Promise<ProcessingJob[]>;
  createProcessingJob(job: InsertProcessingJob): Promise<ProcessingJob>;
  updateProcessingJob(id: number, updates: Partial<ProcessingJob>): Promise<ProcessingJob | undefined>;
  deleteProcessingJob(id: number): Promise<boolean>;

  // Activity Logs
  getActivityLogs(): Promise<ActivityLog[]>;
  getRecentActivityLogs(limit?: number): Promise<ActivityLog[]>;
  createActivityLog(log: InsertActivityLog): Promise<ActivityLog>;

  // Statistics
  getStats(): Promise<{
    totalDocuments: number;
    queueCount: number;
    successRate: number;
    dataPoints: number;
  }>;
}

export class MemStorage implements IStorage {
  private documents: Map<number, Document>;
  private extractions: Map<number, Extraction>;
  private processingJobs: Map<number, ProcessingJob>;
  private activityLogs: Map<number, ActivityLog>;
  private currentDocumentId: number;
  private currentExtractionId: number;
  private currentJobId: number;
  private currentLogId: number;

  constructor() {
    this.documents = new Map();
    this.extractions = new Map();
    this.processingJobs = new Map();
    this.activityLogs = new Map();
    this.currentDocumentId = 1;
    this.currentExtractionId = 1;
    this.currentJobId = 1;
    this.currentLogId = 1;
  }

  // Documents
  async getDocument(id: number): Promise<Document | undefined> {
    return this.documents.get(id);
  }

  async getDocuments(): Promise<Document[]> {
    return Array.from(this.documents.values()).sort((a, b) => 
      new Date(b.uploadedAt).getTime() - new Date(a.uploadedAt).getTime()
    );
  }

  async createDocument(insertDocument: InsertDocument): Promise<Document> {
    const id = this.currentDocumentId++;
    const document: Document = { 
      ...insertDocument, 
      id, 
      uploadedAt: new Date(),
      status: insertDocument.status || "pending",
      processingProgress: insertDocument.processingProgress || 0,
      patientId: insertDocument.patientId ?? null,
      documentType: insertDocument.documentType ?? null,
      errorMessage: insertDocument.errorMessage ?? null
    };
    this.documents.set(id, document);
    return document;
  }

  async updateDocument(id: number, updates: Partial<Document>): Promise<Document | undefined> {
    const document = this.documents.get(id);
    if (!document) return undefined;
    
    const updatedDocument = { ...document, ...updates };
    this.documents.set(id, updatedDocument);
    return updatedDocument;
  }

  async deleteDocument(id: number): Promise<boolean> {
    return this.documents.delete(id);
  }

  async getDocumentsByStatus(status: string): Promise<Document[]> {
    return Array.from(this.documents.values()).filter(doc => doc.status === status);
  }

  async getDocumentsByType(documentType: string): Promise<Document[]> {
    return Array.from(this.documents.values()).filter(doc => doc.documentType === documentType);
  }

  async searchDocuments(query: string): Promise<Document[]> {
    const lowerQuery = query.toLowerCase();
    return Array.from(this.documents.values()).filter(doc => 
      doc.filename.toLowerCase().includes(lowerQuery) ||
      doc.originalName.toLowerCase().includes(lowerQuery) ||
      doc.patientId?.toLowerCase().includes(lowerQuery) ||
      doc.documentType?.toLowerCase().includes(lowerQuery)
    );
  }

  // Extractions
  async getExtraction(id: number): Promise<Extraction | undefined> {
    return this.extractions.get(id);
  }

  async getExtractions(): Promise<Extraction[]> {
    return Array.from(this.extractions.values()).sort((a, b) => 
      new Date(b.extractedAt).getTime() - new Date(a.extractedAt).getTime()
    );
  }

  async getExtractionsByDocument(documentId: number): Promise<Extraction[]> {
    return Array.from(this.extractions.values()).filter(ext => ext.documentId === documentId);
  }

  async createExtraction(insertExtraction: InsertExtraction): Promise<Extraction> {
    const id = this.currentExtractionId++;
    const extraction: Extraction = { 
      ...insertExtraction, 
      id, 
      extractedAt: new Date(),
      confidence: insertExtraction.confidence || 0,
      reviewRequired: insertExtraction.reviewRequired || false
    };
    this.extractions.set(id, extraction);
    return extraction;
  }

  async updateExtraction(id: number, updates: Partial<Extraction>): Promise<Extraction | undefined> {
    const extraction = this.extractions.get(id);
    if (!extraction) return undefined;
    
    const updatedExtraction = { ...extraction, ...updates };
    this.extractions.set(id, updatedExtraction);
    return updatedExtraction;
  }

  async deleteExtraction(id: number): Promise<boolean> {
    return this.extractions.delete(id);
  }

  // Processing Jobs
  async getProcessingJob(id: number): Promise<ProcessingJob | undefined> {
    return this.processingJobs.get(id);
  }

  async getProcessingJobs(): Promise<ProcessingJob[]> {
    return Array.from(this.processingJobs.values());
  }

  async getProcessingJobsByDocument(documentId: number): Promise<ProcessingJob[]> {
    return Array.from(this.processingJobs.values()).filter(job => job.documentId === documentId);
  }

  async getProcessingJobsByStatus(status: string): Promise<ProcessingJob[]> {
    return Array.from(this.processingJobs.values()).filter(job => job.status === status);
  }

  async createProcessingJob(insertJob: InsertProcessingJob): Promise<ProcessingJob> {
    const id = this.currentJobId++;
    const job: ProcessingJob = { 
      ...insertJob, 
      id,
      status: insertJob.status || "queued",
      progress: insertJob.progress || 0,
      startedAt: null,
      completedAt: null,
      errorMessage: insertJob.errorMessage ?? null,
      result: insertJob.result ?? null
    };
    this.processingJobs.set(id, job);
    return job;
  }

  async updateProcessingJob(id: number, updates: Partial<ProcessingJob>): Promise<ProcessingJob | undefined> {
    const job = this.processingJobs.get(id);
    if (!job) return undefined;
    
    const updatedJob = { ...job, ...updates };
    this.processingJobs.set(id, updatedJob);
    return updatedJob;
  }

  async deleteProcessingJob(id: number): Promise<boolean> {
    return this.processingJobs.delete(id);
  }

  // Activity Logs
  async getActivityLogs(): Promise<ActivityLog[]> {
    return Array.from(this.activityLogs.values()).sort((a, b) => 
      new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime()
    );
  }

  async getRecentActivityLogs(limit: number = 10): Promise<ActivityLog[]> {
    const logs = await this.getActivityLogs();
    return logs.slice(0, limit);
  }

  async createActivityLog(insertLog: InsertActivityLog): Promise<ActivityLog> {
    const id = this.currentLogId++;
    const log: ActivityLog = { 
      ...insertLog, 
      id, 
      timestamp: new Date(),
      documentId: insertLog.documentId ?? null
    };
    this.activityLogs.set(id, log);
    return log;
  }

  // Statistics
  async getStats(): Promise<{
    totalDocuments: number;
    queueCount: number;
    successRate: number;
    dataPoints: number;
  }> {
    const allDocuments = Array.from(this.documents.values());
    const allExtractions = Array.from(this.extractions.values());
    const processingJobs = Array.from(this.processingJobs.values());
    
    const totalDocuments = allDocuments.length;
    const queueCount = processingJobs.filter(job => job.status === "queued" || job.status === "processing").length;
    const completedDocuments = allDocuments.filter(doc => doc.status === "completed").length;
    const successRate = totalDocuments > 0 ? Math.round((completedDocuments / totalDocuments) * 100 * 10) / 10 : 0;
    const dataPoints = allExtractions.reduce((sum, ext) => sum + ext.dataPoints, 0);

    return {
      totalDocuments,
      queueCount,
      successRate,
      dataPoints
    };
  }
}

export const storage = new MemStorage();
