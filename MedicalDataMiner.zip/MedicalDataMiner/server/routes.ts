import type { Express, Request } from "express";
import { createServer, type Server } from "http";
import multer from "multer";
import path from "path";
import { storage } from "./storage";
import { fileProcessor } from "./services/file-processor";
import { insertDocumentSchema } from "@shared/schema";

// Configure multer for file uploads
const uploadDir = path.join(process.cwd(), 'uploads');
const upload = multer({
  dest: uploadDir,
  limits: {
    fileSize: 50 * 1024 * 1024, // 50MB limit
  },
  fileFilter: (req: any, file: any, cb: any) => {
    const allowedTypes = [
      'application/pdf',
      'application/msword',
      'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
      'text/plain',
      'image/jpeg',
      'image/png',
      'image/tiff',
      'application/dicom',
      'application/octet-stream'
    ];
    
    if (allowedTypes.includes(file.mimetype)) {
      cb(null, true);
    } else {
      cb(new Error('Unsupported file type'));
    }
  }
});

export async function registerRoutes(app: Express): Promise<Server> {
  // Get dashboard statistics
  app.get("/api/stats", async (req, res) => {
    try {
      const stats = await storage.getStats();
      res.json(stats);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch statistics" });
    }
  });

  // Get all documents
  app.get("/api/documents", async (req, res) => {
    try {
      const { status, type, search } = req.query;
      
      let documents;
      if (search) {
        documents = await storage.searchDocuments(search as string);
      } else if (status) {
        documents = await storage.getDocumentsByStatus(status as string);
      } else if (type) {
        documents = await storage.getDocumentsByType(type as string);
      } else {
        documents = await storage.getDocuments();
      }
      
      res.json(documents);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch documents" });
    }
  });

  // Get single document
  app.get("/api/documents/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const document = await storage.getDocument(id);
      
      if (!document) {
        return res.status(404).json({ error: "Document not found" });
      }
      
      res.json(document);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch document" });
    }
  });

  // Upload single file
  app.post("/api/upload", upload.single('file'), async (req: any, res) => {
    try {
      if (!req.file) {
        return res.status(400).json({ error: "No file uploaded" });
      }

      const documentData = {
        filename: req.file.filename,
        originalName: req.file.originalname,
        fileSize: req.file.size,
        fileType: req.file.mimetype
      };

      const document = await storage.createDocument(documentData);
      
      // Process the file asynchronously
      fileProcessor.processDocument(document, req.file.path).catch(error => {
        console.error('Background processing failed:', error);
      });

      res.json(document);
    } catch (error) {
      res.status(500).json({ error: "Failed to upload file" });
    }
  });

  // Upload multiple files
  app.post("/api/upload/bulk", upload.array('files', 10), async (req: any, res) => {
    try {
      if (!req.files || req.files.length === 0) {
        return res.status(400).json({ error: "No files uploaded" });
      }

      const files = req.files as Express.Multer.File[];
      const documents = [];

      for (const file of files) {
        const documentData = {
          filename: file.filename,
          originalName: file.originalname,
          fileSize: file.size,
          fileType: file.mimetype
        };

        const document = await storage.createDocument(documentData);
        documents.push(document);

        // Process each file asynchronously
        fileProcessor.processDocument(document, file.path).catch(error => {
          console.error('Background processing failed:', error);
        });
      }

      res.json({ documents, count: documents.length });
    } catch (error) {
      res.status(500).json({ error: "Failed to upload files" });
    }
  });

  // Delete document
  app.delete("/api/documents/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const deleted = await storage.deleteDocument(id);
      
      if (!deleted) {
        return res.status(404).json({ error: "Document not found" });
      }
      
      // Also delete related extractions
      const extractions = await storage.getExtractionsByDocument(id);
      for (const extraction of extractions) {
        await storage.deleteExtraction(extraction.id);
      }

      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: "Failed to delete document" });
    }
  });

  // Get extractions for a document
  app.get("/api/documents/:id/extractions", async (req, res) => {
    try {
      const documentId = parseInt(req.params.id);
      const extractions = await storage.getExtractionsByDocument(documentId);
      res.json(extractions);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch extractions" });
    }
  });

  // Get all extractions
  app.get("/api/extractions", async (req, res) => {
    try {
      const extractions = await storage.getExtractions();
      
      // Join with document information
      const extractionsWithDocuments = await Promise.all(
        extractions.map(async (extraction) => {
          const document = await storage.getDocument(extraction.documentId);
          return {
            ...extraction,
            document
          };
        })
      );
      
      res.json(extractionsWithDocuments);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch extractions" });
    }
  });

  // Export data to CSV
  app.get("/api/export/csv", async (req, res) => {
    try {
      const extractions = await storage.getExtractions();
      const extractionsWithDocuments = await Promise.all(
        extractions.map(async (extraction) => {
          const document = await storage.getDocument(extraction.documentId);
          return { ...extraction, document };
        })
      );

      // Create CSV content
      const csvHeader = 'Document Name,File Type,Patient ID,Document Type,Date Extracted,Data Points,Confidence,Review Required\n';
      const csvRows = extractionsWithDocuments.map(item => {
        return [
          item.document?.originalName || '',
          item.document?.fileType || '',
          item.document?.patientId || '',
          item.document?.documentType || '',
          item.extractedAt.toISOString().split('T')[0],
          item.dataPoints,
          item.confidence,
          item.reviewRequired ? 'Yes' : 'No'
        ].join(',');
      }).join('\n');

      const csvContent = csvHeader + csvRows;
      
      res.setHeader('Content-Type', 'text/csv');
      res.setHeader('Content-Disposition', 'attachment; filename=medical_extractions.csv');
      res.send(csvContent);
    } catch (error) {
      res.status(500).json({ error: "Failed to export data" });
    }
  });

  // Get processing jobs
  app.get("/api/processing-jobs", async (req, res) => {
    try {
      const { status } = req.query;
      
      let jobs;
      if (status) {
        jobs = await storage.getProcessingJobsByStatus(status as string);
      } else {
        jobs = await storage.getProcessingJobs();
      }
      
      res.json(jobs);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch processing jobs" });
    }
  });

  // Get recent activity logs
  app.get("/api/activity", async (req, res) => {
    try {
      const limit = req.query.limit ? parseInt(req.query.limit as string) : 10;
      const logs = await storage.getRecentActivityLogs(limit);
      res.json(logs);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch activity logs" });
    }
  });

  // Retry processing for failed document
  app.post("/api/documents/:id/retry", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const document = await storage.getDocument(id);
      
      if (!document) {
        return res.status(404).json({ error: "Document not found" });
      }

      // Reset document status
      await storage.updateDocument(id, {
        status: 'pending',
        processingProgress: 0,
        errorMessage: null
      });

      // Create new processing job
      await storage.createProcessingJob({
        documentId: id,
        jobType: 'retry',
        status: 'queued',
        progress: 0
      });

      res.json({ success: true, message: "Processing retry initiated" });
    } catch (error) {
      res.status(500).json({ error: "Failed to retry processing" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
